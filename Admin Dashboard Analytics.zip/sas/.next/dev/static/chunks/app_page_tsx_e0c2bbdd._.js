(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_4d1a5b12._.js",
  "static/chunks/node_modules_next_dist_compiled_react_583fbf25._.js"
],
    source: "dynamic"
});
